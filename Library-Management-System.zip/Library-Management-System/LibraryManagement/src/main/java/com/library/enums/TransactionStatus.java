package com.library.enums;

public enum TransactionStatus {
    BORROWED, RETURNED
}
