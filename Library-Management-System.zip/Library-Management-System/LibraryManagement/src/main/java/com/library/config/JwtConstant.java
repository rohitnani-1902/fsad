package com.library.config;

public class JwtConstant {
    public static final String SECRET_KEY="dflgjrwlksafhljfncvnmriweurgprojkjdsnwjrouewhsubeghsegrghjbjhpouwhroehrtrtioytrhfnb";
    public static final String JWT_HEADER="Authorization";
}
